module.exports = mongoose => {
  const Upload = mongoose.model(
    "upload",
    mongoose.Schema({
      fileName: {
        type: String,
        required : true
      },
      fileUrl: {
        type : String,
        required: true
      },
      fileType: {
        type: String
      },
      title: {
        type: String
      },
      caption: {
        type: String
      },
      flag: {
        type: String
      }
    }, {
      timestamps: true
    })
  );

  return  Upload;
};
